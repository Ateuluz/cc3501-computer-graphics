from MyObject import MyObject

class MyBody(MyObject):
    
    def __init__(self, position):
        super().__init__()