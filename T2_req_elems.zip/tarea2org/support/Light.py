class Light(object):
    
    def __init__(self, pos, color):
        self.pos   = pos
        self.color = color