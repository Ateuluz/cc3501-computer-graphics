import os
import sys
from pathlib import Path

import numpy as np
import pyglet
import pyglet.gl as GL
import trimesh as tm

import pymunk

if sys.path[0] != "":
    sys.path.insert(0, "")
    
import grafica.transformations as tr

from grafica.textures import texture_2D_setup

# My stuff
from tarea2org.support.Element    import Element
from tarea2org.support.Projection import Projection
from tarea2org.support.View       import View
from tarea2org.support.Light      import Light

import pprint

want_to_print = False
def my_print(*args, **kwargs):
    if want_to_print: print(*args, **kwargs)

if __name__ == "__main__":
    
# Set Window
    window_width  = 800
    window_height = 800
    window = pyglet.window.Window(window_width,window_height)

# Set World
    world = pymunk.Space()
    world.gravity = 0,0
    # world.gravity = (0.0, .35) # Stable
    world.gravity = (0.0, .5)

# Set Program State
    window.program_state = {
        "total_time": 0.0,
        "elements_display": [],
        "elements_interact": [],
        "view": View(),
        "projection": Projection(),
        "mesh_scale": 1,
        "test_scale": 1/2,
        "light_1": Light(np.array([ 4, 3, 4]), np.array([0, .5, 1])),
        "light_2": Light(np.array([-4, 3, 4]), np.array([1, .5, 0])),
    }
    ps = window.program_state

# Set Projections
    ps["projection"].add(
        "perspective",
        tr.perspective(90, float(window_width)/float(window_height), .01, 200)
    )
    ps["projection"].add(
        "perspective2",
        tr.perspective(90, float(window_width)/float(window_height), .01, 400)
    )
    ps["projection"].add(
        "ortho",
        tr.ortho(-1, 1, -1, 1, .01, 10)
    )
    ps["projection"].add(
        "ortho2",
        tr.ortho(-1, 1, -1, 1, .01, 10)
    )

# Set Views
    ps["view"].add(
        0,
        np.array([0.0, 0.8, 0.1]) * .8,
        np.array([0.0, 0.0, -.2]) * .8,
        "perspective"
    )
    ps["view"].add(
        1,
        np.array([1.6, 1.6, 1.6]),
        np.array([0.0, 0.0, 0.0]),
        "ortho2"
    )
    ps["view"].add(
        2,
        np.array([0.0, 0.8, 0.5]),
        np.array([0.0, 0.0, 0.0]),
        "ortho"
    )
    ps["view"].add(
        3,
        np.array([1.6, 1.6, 1.6]) * .1,
        np.array([0.0, 0.0, 0.0]),
        "perspective2"
    )
    
# Set Pipeline
    # Vertex and Fragment
    with open(
        Path(os.path.dirname(__file__))
        / "vertex_program.glsl"
    ) as f:
        vertex_source_code = f.read()

    with open(
        Path(os.path.dirname(__file__))
        / "fragment_program.glsl"
    ) as f:
        fragment_source_code = f.read()

    # Create Pipeline
    vert_shader = pyglet.graphics.shader.Shader(vertex_source_code  , "vertex")
    frag_shader = pyglet.graphics.shader.Shader(fragment_source_code, "fragment")
    flipper_pipeline = pyglet.graphics.shader.ShaderProgram(vert_shader, frag_shader)
    
# Set Elements
    # Get Reference
    ref = tm.load("my_assets/tri_stoneFloor.obj").scale
    ps["mesh_scale"] = 2/ref * ps["test_scale"]
    scale = ps["mesh_scale"]
    
    # Floor
    floor = Element(
        pipeline  = flipper_pipeline,
        mesh_path = "my_assets/tri_stoneFloor.obj",
        transform = tr.uniformScale(scale)
    )
    ps["elements_display"].append(floor)
    
    # Walls
    walls = Element(
        pipeline  = flipper_pipeline,
        mesh_path = "my_assets/tri_fireWalls.obj",
        transform = tr.uniformScale(scale) @ tr.scale(1,1,.999),
        parent    = floor
    )
    ps["elements_display"].append(walls)

    # Flipper Factory
    flipper_base_verts = [(0.005,-0.015),(.055,-.015),(.055,-.005),(0.005,.01)]
    def new_flipper(vertices, transformation=None):
        if transformation is None: transformation = tr.identity() @ tr.uniformScale(scale)
        flipper = Element(
            pipeline  = flipper_pipeline,
            mesh_path = "my_assets/tri_orangeFlipper.obj",
            transform = transformation,
            parent    = floor
        )
        flipper.body  = pymunk.Body(body_type= pymunk.Body.KINEMATIC)
        flipper.shape = pymunk.Poly(flipper.body, vertices= vertices) # TODO
        flipper.body.angle    = 0
        flipper.body.position = (0,0)
        flipper.shape.elasticity = .05
        flipper.shape.collision_type = 2
        ps["elements_display" ].append(flipper)
        ps["elements_interact"].append(flipper)
        return flipper
    
    # Fizq
    flipper_izq = new_flipper(flipper_base_verts)
    # Fder
    flipper_der = new_flipper([(-x,y) for x,y in flipper_base_verts],
                              transformation = tr.uniformScale(scale) @ tr.scale(-1,1,1))
    # Fup
    flipper_up = new_flipper([(x/2,y/2) for x,y in flipper_base_verts])
    
    # Mushroom Factory
    def new_mushroom(radius= .03, transformation=None):
        mushroom = Element(
            pipeline  = flipper_pipeline,
            mesh_path = "my_assets/tri_jpMushroom.obj",
            transform = tr.uniformScale(scale),
            parent    = floor
        )
        mushroom.body  = pymunk.Body(body_type= pymunk.Body.KINEMATIC)
        mushroom.shape = pymunk.Circle(mushroom.body, radius)
        mushroom.shape.elasticity = 1.2
        ps["elements_display" ].append(mushroom)
        ps["elements_interact"].append(mushroom)
        return mushroom
        pass

    
    # Mizq
    mushroom_izq = new_mushroom()
    mushroom_der = new_mushroom()
    mushroom_dwn = new_mushroom()
    mushroom_support = [new_mushroom(.015) for _ in range(6)]
    
    ball = Element(
        pipeline  = flipper_pipeline,
        mesh_path = "my_assets/tri_metBall.obj",
        transform = tr.uniformScale(scale) @ tr.uniformScale(1/8),
        parent    = floor
    )
    ball.set_gpu(True,
                 np.array([255,255,255]),
                 np.array([255,255,255]),
                 np.array([255,255,255]),
                 255) 
    ball_mass  = 0.1
    ball_rad   = 0.02
    ball.body  = pymunk.Body(
        ball_mass,
        pymunk.moment_for_circle(ball_mass, 0, ball_rad)
    )
    ball.shape = pymunk.Circle(ball.body,ball_rad)
    ball.shape.elasticity = .8
    ps["elements_display" ].append(ball)
    ps["elements_interact"].append(ball)

# Set World Elements
    for element in ps["elements_interact"]:
        world.add(element.body, element.shape)
    # world.add(*ps["elements_interact"])
    
# Set Borders
    def add_static_to_wrld(a,b, elasticity = .7, group = 1):
        line = pymunk.Segment(world.static_body, a, b, .0001)
        line.elasticity = elasticity
        line.group = group
        world.add(line)
        return line
    
    # TODO: Add borders
    add_static_to_wrld((-0.255, 0.425),( 0.255, 0.425))
    add_static_to_wrld(( 0.255, 0.425),( 0.255,-0.425))
    add_static_to_wrld(( 0.255,-0.425),(-0.255,-0.425))
    add_static_to_wrld((-0.255,-0.425),(-0.255, 0.425))
    
# Set Roots
    floor.transform_root(
        # ry=(np.pi)
         s = 1.2
    )
    ball.root_set()
    ball.transform_root(
        ty= .01,
        tz= 0,
    )
    walls.root_set()
    walls.transform_root(
        ty= -.001,
        s= .997
    )
    flipper_izq.root_set()
    flipper_izq.transform_root(
        tx= -.15*ps["test_scale"],
        tz=  .6 *ps["test_scale"],
        s =  .8
    )
    flipper_der.root_set()
    flipper_der.transform_root(
        tx=  .15*ps["test_scale"],
        tz=  .6 *ps["test_scale"],
        s =  .8
    )
    flipper_up.root_set()
    flipper_up.transform_root(
        tx= -.3*ps["test_scale"],
        tz= -.5 *ps["test_scale"],
        s =  .5
    )
    mushroom_izq.root_set()
    mushroom_izq.transform_root(
        tx= -.2*ps["test_scale"],
        tz= -.2*ps["test_scale"]
    )
    mushroom_der.root_set()
    mushroom_der.transform_root(
        tx=  .2*ps["test_scale"],
        tz= -.2*ps["test_scale"]
    )
    mushroom_dwn.root_set()
    
    support_coors = [(-.39,.4),(-.22,.57),(-.32,.5),(.39,.4),(.22,.57),(.32,.5),]
    for i,mush in enumerate(mushroom_support):
        x,z = support_coors[i]
        mush.root_set()
        mush.transform_root(
            tx=  x*ps["test_scale"],
            tz=  z*ps["test_scale"],
            s =  .5
        )
        
# Set Special Functions
    def ball_remove(arbiter,space,data):
        print(data)
    
# Set Key Actions
    key = pyglet.window.key
    ang_vel = 22

    @window.event
    def on_key_press(symbol,modifiers):
        view   :View = ps["view"]
        if symbol == key.A:
            my_print(flipper_izq.body.position)
            flipper_izq.body.angular_velocity = -ang_vel
            flipper_up.body.angular_velocity  = -ang_vel
            my_print(flipper_izq.body.position)
        elif symbol == key.D:
            flipper_der.body.angular_velocity = ang_vel
        elif symbol == key.C:
            view.next()
            ps["projection"].current = view.projection
        elif symbol == key.P:
            print("Program State")
            pprint.pprint(ps)
            print("floor.root()")
            pprint.pprint(floor.root)
        elif symbol == key.SPACE:
            ball.move_body(-0.01,-0.2)
            ball.move_body(-0.05,-0.3)
        elif symbol == key.UP:
            ball.body.position += pymunk.Vec2d(0,-.01) 
            print(ball.body.position)
        elif symbol == key.DOWN:
            ball.body.position += pymunk.Vec2d(0,.01) 
            print(ball.body.position)
        elif symbol == key.RIGHT:
            ball.body.position += pymunk.Vec2d(.01,0) 
            print(ball.body.position)
        elif symbol == key.LEFT:
            ball.body.position += pymunk.Vec2d(-.01,0) 
            print(ball.body.position)
        elif symbol == key.G:
            print(">> -=- <<")
        
    @window.event
    def on_key_release(symbol,modifiers):
        if symbol == key.A:
            flipper_izq.body.angular_velocity = ang_vel
            flipper_up.body.angular_velocity  = ang_vel
        elif symbol == key.D:
            flipper_der.body.angular_velocity = -ang_vel
            
# Set Special Draw Functions
    def ball_func(ball:Element):
        updated_root = ball.root.copy()
        x,z = ball.body.position
        updated_root @= tr.translate(x, 0, z)
        return updated_root
    
    def flipper_func(flipper:Element): # TODO
        updated_root = flipper.root.copy() @ tr.identity()
        angle = flipper.body.angle
        updated_root @= tr.rotationY(-angle)
        return updated_root
        
# Set Draw
    @window.event
    def on_draw():
        GL.glClearColor(0.0, 0.6, 0.5, 1.0)
        GL.glLineWidth(1.0)
        GL.glBlendFunc(GL.GL_SRC_ALPHA, GL.GL_ONE_MINUS_SRC_ALPHA)
        GL.glEnable(GL.GL_DEPTH_TEST)
        window.clear()
        
        GL.glPolygonMode(GL.GL_FRONT_AND_BACK, GL.GL_FILL)
        flipper_pipeline.use()
        
        flipper_pipeline["lightPosition1"] = ps["light_1"].pos
        flipper_pipeline["lightPosition2"] = ps["light_2"].pos
        
        view:View             = ps["view"]
        projection:Projection = ps["projection"].get()
        
        flipper_pipeline["projection"] = projection
        flipper_pipeline["viewPosition"] = view.vec3from()
        flipper_pipeline["view"] = view.matrix().reshape(16, 1, order="F")
        
        ball        .transform_func = ball_func
        flipper_izq .transform_func = flipper_func
        flipper_der .transform_func = flipper_func
        flipper_up  .transform_func = flipper_func
        
        elements:list[Element] = ps["elements_display"]
        for element in elements: element.draw()
        
# Set Update World
    def update_world(dt, window):
        window.program_state["total_time"] += dt
        my_print("In update_world before step:", flipper_izq.body.position)
        
        n = 10
        for _ in range(n):
            # BUG
            world.step(dt / n)
        
        my_print("In update_world after step:", flipper_izq.body.position)
        
        # for flipper in [flipper_izq, flipper_der, flipper_up]:
        #     if any(map(lambda x: not x == x, flipper.body.position)) or not flipper.body.angle == flipper.body.angle:
        #         print("Nan found: force reset")
        #         flipper.body.position = (0, 0)  # Reset position
        #         flipper.body.angle = 0  # Reset angle
        
        # We'll brute force the rotation limits
        flipper_izq.body.angle = max(-np.pi * 3 / 16, min(np.pi * 3 / 16, flipper_izq.body.angle))
        if abs(flipper_izq.body.angle) + 0.001 > np.pi * 3 / 16:
            flipper_izq.body.angular_velocity = 0
        flipper_der.body.angle = max(-np.pi * 3 / 16, min(np.pi * 3 / 16, flipper_der.body.angle))
        if abs(flipper_der.body.angle) + 0.001 > np.pi * 3 / 16:
            flipper_der.body.angular_velocity = 0
        flipper_up.body.angle = max(-0, min(np.pi / 2, flipper_up.body.angle))
        if (flipper_up.body.angle - 0.001 < 0) or flipper_up.body.angle - 0.001 > np.pi / 2:
            flipper_up.body.angular_velocity = 0
        

# Begin
    ps["projection"].current = ps["view"].projection
    pyglet.clock.schedule_interval(update_world, 1 / 60.0, window)
    pyglet.app.run(1 / 60.0)